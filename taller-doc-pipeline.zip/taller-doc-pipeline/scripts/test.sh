#!/bin/bash
# ============================================================
# test.sh — Probar el pipeline subiendo un documento
# Taller: Antigravity en acción - WildWid AI 2026
# ============================================================

export PROJECT_ID=$(gcloud config get-value project)
export BUCKET_NAME="${PROJECT_ID}-documentos"
export DATASET_NAME="documentos_procesados"
export TABLE_NAME="extracciones"

# Archivo a subir — usar el de samples/ o pasar como argumento
SAMPLE_FILE=${1:-"samples/sample_invoice.pdf"}

echo ""
echo "=============================================="
echo " 🧪 TEST del pipeline ETL"
echo "=============================================="
echo ""

# Verificar que el archivo existe
if [ ! -f "$SAMPLE_FILE" ]; then
    echo "❌ Archivo no encontrado: $SAMPLE_FILE"
    echo "   Uso: bash scripts/test.sh [ruta/al/archivo.pdf]"
    echo "   Ejemplo: bash scripts/test.sh samples/sample_invoice.pdf"
    exit 1
fi

echo "📄 Subiendo archivo: $SAMPLE_FILE"
gsutil cp "$SAMPLE_FILE" gs://${BUCKET_NAME}/

echo ""
echo "⏳ Esperando que la Cloud Function procese el archivo..."
echo "   (El trigger puede tardar 10-30 segundos en activarse)"
sleep 30

echo ""
echo "📊 Verificando resultados en BigQuery..."
bq query --use_legacy_sql=false \
    "SELECT 
        file_name,
        processed_at,
        vendor_name,
        document_date,
        document_number,
        total_amount,
        currency,
        processing_status
     FROM \`${PROJECT_ID}.${DATASET_NAME}.${TABLE_NAME}\`
     ORDER BY processed_at DESC
     LIMIT 5"

echo ""
echo "✅ Test completado. Verificá los resultados arriba."
echo ""
echo "Para ver los logs de la Cloud Function:"
echo "   gcloud functions logs read process-document --region=us-central1 --gen2 --limit=50"
echo ""
