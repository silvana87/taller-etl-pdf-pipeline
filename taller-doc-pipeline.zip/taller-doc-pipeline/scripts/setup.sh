#!/bin/bash
# ============================================================
# setup.sh — Configuración completa del entorno
# Taller: Antigravity en acción - WildWid AI 2026
# ============================================================
# Este script configura todos los recursos necesarios en GCP:
#   - Habilita las APIs requeridas
#   - Crea el bucket de Cloud Storage
#   - Asigna permisos de Pub/Sub a la cuenta de servicio de GCS
#   - Crea el dataset y tabla en BigQuery
#   - Despliega la Cloud Function con el código del pipeline ETL
#
# Uso:
#   bash setup.sh
#
# Prerequisitos:
#   - gcloud CLI instalado y autenticado
#   - Proyecto GCP con billing habilitado
#   - Ejecutar desde la carpeta raíz del repositorio
# ============================================================

set -e  # Detener si cualquier comando falla

# ============================================================
# CONFIGURACIÓN — Modificar según tu proyecto
# ============================================================
export PROJECT_ID=$(gcloud config get-value project)
export REGION="us-central1"
export BUCKET_NAME="${PROJECT_ID}-documentos"
export DATASET_NAME="documentos_procesados"
export TABLE_NAME="extracciones"
export FUNCTION_NAME="process-document"
export MEMORY="512MB"

# ============================================================
# VALIDACIONES INICIALES
# ============================================================
echo ""
echo "=============================================="
echo " TALLER: Antigravity en acción - WildWid AI"
echo "=============================================="
echo ""
echo "📋 Configuración:"
echo "   Proyecto : $PROJECT_ID"
echo "   Región   : $REGION"
echo "   Bucket   : $BUCKET_NAME"
echo "   Dataset  : $DATASET_NAME"
echo "   Tabla    : $TABLE_NAME"
echo "   Función  : $FUNCTION_NAME"
echo "   Memoria  : $MEMORY"
echo ""

if [ -z "$PROJECT_ID" ]; then
    echo "❌ Error: No se encontró el PROJECT_ID."
    echo "   Ejecutá: gcloud config set project TU_PROYECTO_ID"
    exit 1
fi

read -p "¿Confirmar configuración? (y/n): " confirm
if [ "$confirm" != "y" ]; then
    echo "Setup cancelado."
    exit 0
fi

# ============================================================
# PASO 1: Habilitar APIs
# ============================================================
echo ""
echo "🔧 Paso 1/6: Habilitando APIs necesarias..."
gcloud services enable \
    cloudfunctions.googleapis.com \
    cloudbuild.googleapis.com \
    storage.googleapis.com \
    bigquery.googleapis.com \
    aiplatform.googleapis.com \
    eventarc.googleapis.com \
    run.googleapis.com \
    pubsub.googleapis.com \
    --project=${PROJECT_ID}
echo "✅ APIs habilitadas correctamente."

# ============================================================
# PASO 2: Crear bucket de Cloud Storage
# ============================================================
echo ""
echo "🪣 Paso 2/6: Creando bucket de Cloud Storage..."
if gsutil ls gs://${BUCKET_NAME} &>/dev/null; then
    echo "   ⚠️  El bucket gs://${BUCKET_NAME} ya existe. Saltando creación."
else
    gcloud storage buckets create gs://${BUCKET_NAME} \
        --location=${REGION} \
        --uniform-bucket-level-access \
        --project=${PROJECT_ID}
    echo "✅ Bucket creado: gs://${BUCKET_NAME}"
fi

# ============================================================
# PASO 3: Configurar permisos de Pub/Sub para Cloud Storage
# NOTA: Este paso es crítico para que el trigger de Eventarc funcione.
# La cuenta de servicio de GCS necesita el rol pubsub.publisher
# para poder publicar eventos cuando se suben archivos al bucket.
# ============================================================
echo ""
echo "🔑 Paso 3/6: Configurando permisos de Pub/Sub..."

# Crear la identidad de servicio de Cloud Storage si no existe
gcloud beta services identity create \
    --service=storage.googleapis.com \
    --project=${PROJECT_ID} 2>/dev/null || true

# Obtener la cuenta de servicio de GCS
GCS_SA=$(gcloud storage service-agent --project=${PROJECT_ID})
echo "   Cuenta de servicio GCS: ${GCS_SA}"

# Asignar rol de Pub/Sub Publisher
gcloud projects add-iam-policy-binding ${PROJECT_ID} \
    --member="serviceAccount:${GCS_SA}" \
    --role="roles/pubsub.publisher" \
    --condition=None \
    --quiet
echo "✅ Permisos de Pub/Sub configurados correctamente."

# ============================================================
# PASO 4: Crear dataset y tabla en BigQuery
# ============================================================
echo ""
echo "📊 Paso 4/6: Configurando BigQuery..."

# Crear dataset si no existe
if bq ls --project_id=${PROJECT_ID} ${DATASET_NAME} &>/dev/null; then
    echo "   ⚠️  El dataset ${DATASET_NAME} ya existe. Saltando creación."
else
    bq mk \
        --dataset \
        --location=${REGION} \
        --description="Dataset del pipeline ETL de documentos - Taller WildWid AI" \
        ${PROJECT_ID}:${DATASET_NAME}
    echo "✅ Dataset creado: ${DATASET_NAME}"
fi

# Crear tabla si no existe
if bq ls --project_id=${PROJECT_ID} ${DATASET_NAME}.${TABLE_NAME} &>/dev/null; then
    echo "   ⚠️  La tabla ${TABLE_NAME} ya existe. Saltando creación."
else
    bq mk \
        --table \
        --description="Tabla de extracciones de documentos procesados con Gemini" \
        ${PROJECT_ID}:${DATASET_NAME}.${TABLE_NAME} \
        bigquery/schema.json
    echo "✅ Tabla creada: ${DATASET_NAME}.${TABLE_NAME}"
fi

# ============================================================
# PASO 5: Desplegar Cloud Function
# ============================================================
echo ""
echo "⚡ Paso 5/6: Desplegando Cloud Function..."
echo "   Esto puede tardar 3-5 minutos..."

gcloud functions deploy ${FUNCTION_NAME} \
    --gen2 \
    --runtime=python311 \
    --region=${REGION} \
    --source=./function \
    --entry-point=process_document \
    --trigger-event-filters="type=google.cloud.storage.object.v1.finalized" \
    --trigger-event-filters="bucket=${BUCKET_NAME}" \
    --set-env-vars PROJECT_ID=${PROJECT_ID},REGION=${REGION} \
    --memory=${MEMORY} \
    --timeout=300s \
    --project=${PROJECT_ID}

echo "✅ Cloud Function desplegada correctamente."

# ============================================================
# PASO 6: Verificar el setup
# ============================================================
echo ""
echo "🔍 Paso 6/6: Verificando el setup..."

echo ""
echo "   Bucket:"
gsutil ls gs://${BUCKET_NAME}

echo ""
echo "   Dataset BigQuery:"
bq ls --project_id=${PROJECT_ID} ${DATASET_NAME}

echo ""
echo "   Cloud Function:"
gcloud functions describe ${FUNCTION_NAME} \
    --region=${REGION} \
    --gen2 \
    --format="value(state)" \
    --project=${PROJECT_ID}

# ============================================================
# RESUMEN FINAL
# ============================================================
echo ""
echo "=============================================="
echo " ✅ SETUP COMPLETADO EXITOSAMENTE"
echo "=============================================="
echo ""
echo "Recursos creados:"
echo "   🪣 Bucket    : gs://${BUCKET_NAME}"
echo "   📊 BigQuery  : ${PROJECT_ID}.${DATASET_NAME}.${TABLE_NAME}"
echo "   ⚡ Function  : ${FUNCTION_NAME} (${REGION})"
echo ""
echo "Próximo paso — Subir un documento de prueba:"
echo "   gsutil cp samples/sample_invoice.pdf gs://${BUCKET_NAME}/"
echo ""
echo "Verificar resultados en BigQuery:"
echo "   bq query --use_legacy_sql=false \\"
echo "   'SELECT * FROM \`${PROJECT_ID}.${DATASET_NAME}.${TABLE_NAME}\` ORDER BY processed_at DESC LIMIT 5'"
echo ""
