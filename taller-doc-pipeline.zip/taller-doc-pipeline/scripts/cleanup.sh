#!/bin/bash
# ============================================================
# cleanup.sh — Eliminar todos los recursos del taller
# Taller: Antigravity en acción - WildWid AI 2026
# ============================================================
# IMPORTANTE: Este script elimina PERMANENTEMENTE todos los
# recursos creados durante el taller. Ejecutar al finalizar
# para evitar costos innecesarios.
# ============================================================

set -e

export PROJECT_ID=$(gcloud config get-value project)
export REGION="us-central1"
export BUCKET_NAME="${PROJECT_ID}-documentos"
export DATASET_NAME="documentos_procesados"
export FUNCTION_NAME="process-document"

echo ""
echo "=============================================="
echo " ⚠️  CLEANUP - Eliminando recursos del taller"
echo "=============================================="
echo ""
echo "Se eliminarán los siguientes recursos:"
echo "   🪣 Bucket    : gs://${BUCKET_NAME}"
echo "   📊 BigQuery  : ${DATASET_NAME}"
echo "   ⚡ Function  : ${FUNCTION_NAME}"
echo ""
echo "⚠️  Esta acción es IRREVERSIBLE."
echo ""

read -p "¿Confirmar eliminación? (escribe 'eliminar' para confirmar): " confirm
if [ "$confirm" != "eliminar" ]; then
    echo "Cleanup cancelado."
    exit 0
fi

# Eliminar Cloud Function
echo ""
echo "🗑️  Eliminando Cloud Function..."
gcloud functions delete ${FUNCTION_NAME} \
    --region=${REGION} \
    --gen2 \
    --quiet \
    --project=${PROJECT_ID} || echo "   ⚠️  La función no existe o ya fue eliminada."
echo "✅ Cloud Function eliminada."

# Eliminar bucket y su contenido
echo ""
echo "🗑️  Eliminando bucket de Cloud Storage..."
gsutil -m rm -r gs://${BUCKET_NAME} || echo "   ⚠️  El bucket no existe o ya fue eliminado."
echo "✅ Bucket eliminado."

# Eliminar dataset de BigQuery
echo ""
echo "🗑️  Eliminando dataset de BigQuery..."
bq rm -r -f --dataset ${PROJECT_ID}:${DATASET_NAME} || echo "   ⚠️  El dataset no existe o ya fue eliminado."
echo "✅ Dataset eliminado."

echo ""
echo "=============================================="
echo " ✅ CLEANUP COMPLETADO"
echo "=============================================="
echo ""
echo "Todos los recursos del taller han sido eliminados."
echo "No se generarán costos adicionales por estos recursos."
echo ""
